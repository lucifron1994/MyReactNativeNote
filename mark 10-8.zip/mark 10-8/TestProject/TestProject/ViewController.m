//
//  ViewController.m
//  TestProject
//
//  Created by macmini_douyu on 16/10/8.
//  Copyright © 2016年 wanghong. All rights reserved.
//

#import "ViewController.h"
#import "MySearchBar.h"
#import <objc/runtime.h>

@interface ViewController ()

@property (strong, nonatomic) MySearchBar *searchBar;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.searchBar = [[MySearchBar alloc]initWithFrame:CGRectMake(20, 100, 335, 60)];
    self.searchBar.placeholder = @"placeholder";
    [self.view addSubview:self.searchBar];
    
    [self.searchBar setValue:@0 forKey:@"centerPlaceholder"];
    
//    [self getAllProperty:[UISearchBar class]];
//    [self runTests:[UISearchBar class]];
    
    [self getAllProperty:[self class]];
    [self runTests:[self class]];
}


- (void)getAllProperty:(Class )cls {
    // 获取当前类的所有属性
    unsigned int count;// 记录属性个数
    objc_property_t *properties = class_copyPropertyList(cls, &count);
    // 遍历
    NSMutableArray *mArray = [NSMutableArray array];
    for (int i = 0; i < count; i++) {
        
        // An opaque type that represents an Objective-C declared property.
        // objc_property_t 属性类型
        objc_property_t property = properties[i];
        // 获取属性的名称 C语言字符串
        const char *cName = property_getName(property);
        // 转换为Objective C 字符串
        NSString *name = [NSString stringWithCString:cName encoding:NSUTF8StringEncoding];
        [mArray addObject:name];
    }
    
    NSLog(@"____%@",mArray);
    
}

- (void)runTests:(Class )cls
{
    unsigned int count;
    Method *methods = class_copyMethodList(cls, &count);
    for (int i = 0; i < count; i++)
    {
        Method method = methods[i];
        SEL selector = method_getName(method);
        NSString *name = NSStringFromSelector(selector);
        
        const char *type =  method_getTypeEncoding(method);
        
        NSLog(@"方法 名字 ==== %@ Type %s",name,type);
        if (name)
        {
            //avoid arc warning by using c runtime
            //            objc_msgSend(self, selector);
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setString:(NSString *)string{
    
}

- (void)setNumber:(NSInteger)intnum{
    
}

@end
