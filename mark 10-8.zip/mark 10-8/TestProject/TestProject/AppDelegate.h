//
//  AppDelegate.h
//  TestProject
//
//  Created by macmini_douyu on 16/10/8.
//  Copyright © 2016年 wanghong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

