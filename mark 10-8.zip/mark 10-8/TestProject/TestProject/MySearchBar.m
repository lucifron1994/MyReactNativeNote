//
//  MySearchBar.m
//  TestProject
//
//  Created by macmini_douyu on 16/10/8.
//  Copyright © 2016年 wanghong. All rights reserved.
//

#import "MySearchBar.h"

@implementation MySearchBar

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
